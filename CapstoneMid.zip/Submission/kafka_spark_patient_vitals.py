#Importing spark libraries 
from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from pyspark.sql.types import *

#Steps to create spark session
Spark = SparkSession  \
        .builder  \
        .appName("StructuredSocketRead")  \
        .getOrCreate()
Spark.sparkContext.setLogLevel('ERROR')

#Read the data from kafka server from bootstrap servers to the subscribed topics
lines =Spark  \
        .readStream  \
        .format("kafka")  \
        .option("kafka.bootstrap.servers","54.235.197.8:9092")  \
        .option("subscribe","PatientInformation")  \
        .load()
#Casting the data as string in dat frame
kafkaDF = lines.selectExpr("cast(value as string)","cast(Timestamp as string)")

#Altering the data in order to get  CustomerID, HeartbeatRate,BloodPressure values in respective columns.Store it in a new data frame

kafkaDF1 = kafkaDF.withColumn('CustomerID', split(kafkaDF['value'], ',').getItem(0)) \
       .withColumn('HeartbeatRate', split(kafkaDF['value'], ',').getItem(1)) \
       .withColumn('BloodPressure', split(kafkaDF['value'], ',').getItem(2))
#Remove the special characters like (, ] [) and store it in new datframe

kafkaDF2 = kafkaDF1 \
       .withColumn('CustomerID',regexp_replace('CustomerID', '"', '')) \
       .withColumn('BloodPressure',regexp_replace('BloodPressure', '"', ''))

#Create a new dataframe to save the final data.
kafkaDF3 = kafkaDF2.select('CustomerID','HeartBeatRate','BloodPressure','Timestamp')

Streaming data using the producer program must be consumed and shown in console as batches
KafkaQuery = kafkaDF3  \
        .writeStream  \
        .outputMode("append")  \
        .format("console")  \
        .option("truncate", "false") \
        .start()

#Write the streeaming data to parquet files .
KafkaQuery1= kafkaDF3.writeStream.outputMode("Append") \
.format("parquet") \
.option("format","append") \
.option("path","PatientInfo") \
.option("checkpointLocation", "PatientInfoCheckpoint") \
.trigger(processingTime="1 minute") \
.start()

KafkaQuery.awaitTermination()
KafkaQuery1.awaitTermination()
