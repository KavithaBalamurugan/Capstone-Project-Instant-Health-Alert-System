#Importing the libraries 
from kafka import KafkaProducer
import mysql.connector
import time
import json
##Import the required files related to sql connectors and kafka .To install sql connector us the command "pip install mysql-connector-python-rf" and if kafka is not installed use the commmand "pip install kafka"

#To access the two databases stored in RDS, use "mysql.connector".##Credentials  are database name : "testdatabase" and the two tables in it are: "patients_vital_info" and "patients_information". The vital information will be consumed by the python producer application
connection = mysql.connector.connect(host='upgraddetest.cyaielc9bmnf.us-east-1.rds.amazonaws.com', database='testdatabase',user='student', password='STUDENT123')
cursor=connection.cursor()
statement='SELECT * FROM patients_vital_info'
cursor.execute(statement)
data=cursor.fetchall()
##Setting up the producer configurations using the credentials given.
producer = KafkaProducer(bootstrap_servers=['localhost:9092'],api_version=(0,10,1),value_serializer=lambda x:json.dumps(x).encode('utf-8'))

##Fetching the data fron patients_vital_info
for i in data:
        patientdata=','.join(str(j) for j in i)
        producer.send('PatientInformation',str(patientdata))
        print(patientdata)
        time.sleep(1)
