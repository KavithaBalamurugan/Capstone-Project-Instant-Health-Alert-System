import json
import boto3
from kafka import KafkaConsumer
import sys



ARN="arn:aws:sns:us-east-1:554109366355:PatientHealthNotification"

bootstrap_servers = ['localhost:9092']
TopicName = 'PatientHealthNotification'
HealthNotificationInput  = KafkaConsumer (TopicName,bootstrap_servers = bootstrap_servers)


for HeathInfo in HealthNotificationInput:
    print("%s" % (HeathInfo.value))
    client = boto3.client('sns','us-east-1')
    response = client.publish(TargetArn=ARN,Message=HeathInfo.value)
