#Importing Libraries
from os.path import abspath
from pyspark.sql import SparkSession
from pyspark.sql import Row

#Referring the  hive tables loaction
HiveTable_Loc= abspath('spark-warehouse')
#Definiing the Spark session
sc = SparkSession \
    .builder \
    .appName("Python Spark SQL Hive integration") \
    .config("spark.sql.warehouse.dir", warehouse_location) \
    .enableHiveSupport() \
    .getOrCreate()

PatientData = sys.argv[1]
	


Slct_Columns = sc.sql(""SELECT heartbeat,BP FROM JoinTable1")


# Retrieving the data in 3 hive table
sc.sql("SELECT * FROM PatientInformation").show()
sc.sql("SELECT * FROM Patientcontactinfo").show()
sc.sql("SELECT * FROM ThresholdValuetable").show()


sc.table("PatientInformation") \
	.filter(expr("age != 'null'")) \
    .createOrReplaceTempView("JoinTable1")

#Store the joined tabled in Data frame
JointableFinal = Row("CustomerID", "value")
JointableDF = spark.createDataFrame([JointableFinal(i, "val_" + str(i)) for i in range(1, 101)])
JointableDF.createOrReplaceTempView("Data")

